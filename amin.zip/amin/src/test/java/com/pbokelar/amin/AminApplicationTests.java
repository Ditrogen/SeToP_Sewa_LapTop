package com.pbokelar.amin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AminApplicationTests {

	@Test
	void contextLoads() {
	}

}
