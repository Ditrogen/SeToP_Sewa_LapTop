package com.pbokelar.amin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AminApplication {

	public static void main(String[] args) {
		SpringApplication.run(AminApplication.class, args);
	}

}
